#include <QHostAddress>
#include <iostream>
#include <QMessageBox>
#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);


    /*************************
     *  Connection to server *
     ************************/
    QHostAddress hostname;
    hostname.setAddress("127.0.0.1");
    m_socket = new QTcpSocket;
    connect(m_socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(networkErrorHandler(QAbstractSocket::SocketError)));
    m_socket->connectToHost(hostname, 3074);

    connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(sendMessage()));

}

Widget::~Widget()
{
    delete ui;
}


void Widget::sendMessage(void)
{
    QString data = ui->textEdit->toPlainText() + "\n";

    if(!data.isEmpty())
    {
        m_socket->write(data.toUtf8());
    }

}



void Widget::networkErrorHandler(QAbstractSocket::SocketError)
{
    QMessageBox::critical(this, "Network critical error", m_socket->errorString());
    this->close();
}
