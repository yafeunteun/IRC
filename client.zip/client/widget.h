#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT
    
public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    
private:
    Ui::Widget *ui;
    QTcpSocket *m_socket;
    char * m_data;          // message to send (the one entered in the texEdit widget

public slots:
    void sendMessage(void);
    void networkErrorHandler(QAbstractSocket::SocketError);
};

#endif // WIDGET_H
